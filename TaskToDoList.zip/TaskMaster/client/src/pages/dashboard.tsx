import { useState } from "react";
import TaskStatistics from "@/components/task-statistics";
import TaskForm from "@/components/task-form";
import TaskList from "@/components/task-list";
import { ClipboardList, User } from "lucide-react";

export default function Dashboard() {
  const [activeFilter, setActiveFilter] = useState<string>("all");

  const currentDate = new Date().toLocaleDateString("en-US", {
    weekday: "long",
    month: "short",
    day: "numeric",
    year: "numeric"
  });

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <ClipboardList className="text-blue-600 text-2xl mr-3 h-8 w-8" />
              <h1 className="text-xl font-semibold text-gray-900">TaskFlow Dashboard</h1>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-500">{currentDate}</span>
              <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                <User className="text-blue-600 h-4 w-4" />
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Statistics Overview */}
        <TaskStatistics />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Task Creation Form */}
          <div className="lg:col-span-1">
            <TaskForm />
          </div>

          {/* Task Management */}
          <div className="lg:col-span-2">
            <TaskList 
              activeFilter={activeFilter} 
              onFilterChange={setActiveFilter} 
            />
          </div>
        </div>
      </main>
    </div>
  );
}
