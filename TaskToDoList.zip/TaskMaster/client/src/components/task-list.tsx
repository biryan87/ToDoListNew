import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ClipboardList } from "lucide-react";
import TaskItem from "@/components/task-item";
import type { Task, TaskStatus } from "@shared/schema";

interface TaskListProps {
  activeFilter: string;
  onFilterChange: (filter: string) => void;
}

export default function TaskList({ activeFilter, onFilterChange }: TaskListProps) {
  const { data: tasks = [], isLoading } = useQuery<Task[]>({
    queryKey: ["/api/tasks"],
  });

  const filteredTasks = tasks.filter(task => {
    if (activeFilter === "all") return true;
    return task.status === activeFilter;
  });

  const filterButtons = [
    { key: "all", label: "All Tasks" },
    { key: "pending", label: "Pending" },
    { key: "progress", label: "In Progress" },
    { key: "completed", label: "Completed" },
    { key: "hold", label: "On Hold" },
  ];

  if (isLoading) {
    return (
      <Card>
        <div className="p-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900">Task Management</h3>
        </div>
        <CardContent className="p-6">
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                  <div className="flex items-center space-x-4 flex-1">
                    <div className="w-20 h-6 bg-gray-200 rounded"></div>
                    <div className="flex-1">
                      <div className="h-5 bg-gray-200 rounded mb-2"></div>
                      <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    <div className="w-20 h-8 bg-gray-200 rounded"></div>
                    <div className="w-8 h-8 bg-gray-200 rounded"></div>
                    <div className="w-8 h-8 bg-gray-200 rounded"></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      {/* Task Filters */}
      <div className="p-6 border-b border-gray-200">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <h3 className="text-lg font-semibold text-gray-900">Task Management</h3>
          
          <div className="flex flex-wrap gap-2">
            {filterButtons.map(({ key, label }) => (
              <Button
                key={key}
                variant={activeFilter === key ? "default" : "ghost"}
                size="sm"
                onClick={() => onFilterChange(key)}
                className={`px-3 py-1.5 text-sm font-medium transition-colors ${
                  activeFilter === key
                    ? "bg-blue-100 text-blue-700 hover:bg-blue-200"
                    : "text-gray-600 hover:bg-gray-100"
                }`}
                data-testid={`button-filter-${key}`}
              >
                {label}
              </Button>
            ))}
          </div>
        </div>
      </div>

      {/* Task List */}
      <CardContent className="p-6">
        {filteredTasks.length > 0 ? (
          <div className="space-y-4" data-testid="task-list-container">
            {filteredTasks.map((task) => (
              <TaskItem key={task.id} task={task} />
            ))}
          </div>
        ) : (
          <div className="text-center py-12" data-testid="empty-state">
            <ClipboardList className="h-16 w-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No tasks found</h3>
            <p className="text-gray-500">
              {activeFilter === "all" 
                ? "Create a new task to get started." 
                : "Try adjusting your filter or create a new task."}
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}