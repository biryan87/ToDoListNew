import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Clock, LoaderPinwheel, CheckCircle, PauseCircle, Clipboard } from "lucide-react";
import type { TaskStatistics } from "@shared/schema";

export default function TaskStatistics() {
  const { data: statistics, isLoading } = useQuery<TaskStatistics>({
    queryKey: ["/api/tasks/statistics"],
  });

  if (isLoading) {
    return (
      <section className="mb-8">
        <div className="mb-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Task Overview</h2>
          <p className="text-gray-600">Track your productivity with real-time statistics</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
          {[...Array(5)].map((_, i) => (
            <Card key={i} className="p-6 animate-pulse">
              <div className="flex items-center">
                <div className="p-2 bg-gray-200 rounded-lg w-10 h-10"></div>
                <div className="ml-4 flex-1">
                  <div className="h-4 bg-gray-200 rounded mb-2"></div>
                  <div className="h-6 bg-gray-200 rounded"></div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </section>
    );
  }

  const stats = statistics || {
    total: 0,
    pending: 0,
    progress: 0,
    completed: 0,
    hold: 0,
    pendingPercentage: 0,
    progressPercentage: 0,
    completedPercentage: 0,
    holdPercentage: 0,
  };

  return (
    <section className="mb-8">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Task Overview</h2>
        <p className="text-gray-600">Track your productivity with real-time statistics</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
        {/* Total Tasks Card */}
        <Card className="p-6 hover:shadow-md transition-shadow" data-testid="card-total-tasks">
          <div className="flex items-center">
            <div className="p-2 bg-gray-100 rounded-lg">
              <Clipboard className="text-gray-600 h-5 w-5" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Total Tasks</p>
              <p className="text-2xl font-bold text-gray-900" data-testid="text-total-count">
                {stats.total}
              </p>
            </div>
          </div>
        </Card>

        {/* Pending Tasks Card */}
        <Card className="p-6 hover:shadow-md transition-shadow" data-testid="card-pending-tasks">
          <div className="flex items-center">
            <div className="p-2 bg-amber-100 rounded-lg">
              <Clock className="text-amber-600 h-5 w-5" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Pending</p>
              <p className="text-2xl font-bold text-amber-600" data-testid="text-pending-count">
                {stats.pending}
              </p>
              <p className="text-xs text-gray-500" data-testid="text-pending-percentage">
                {stats.pendingPercentage}%
              </p>
            </div>
          </div>
        </Card>

        {/* In Progress Tasks Card */}
        <Card className="p-6 hover:shadow-md transition-shadow" data-testid="card-progress-tasks">
          <div className="flex items-center">
            <div className="p-2 bg-blue-100 rounded-lg">
              <LoaderPinwheel className="text-blue-600 h-5 w-5" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">In Progress</p>
              <p className="text-2xl font-bold text-blue-600" data-testid="text-progress-count">
                {stats.progress}
              </p>
              <p className="text-xs text-gray-500" data-testid="text-progress-percentage">
                {stats.progressPercentage}%
              </p>
            </div>
          </div>
        </Card>

        {/* Completed Tasks Card */}
        <Card className="p-6 hover:shadow-md transition-shadow" data-testid="card-completed-tasks">
          <div className="flex items-center">
            <div className="p-2 bg-emerald-100 rounded-lg">
              <CheckCircle className="text-emerald-600 h-5 w-5" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Completed</p>
              <p className="text-2xl font-bold text-emerald-600" data-testid="text-completed-count">
                {stats.completed}
              </p>
              <p className="text-xs text-gray-500" data-testid="text-completed-percentage">
                {stats.completedPercentage}%
              </p>
            </div>
          </div>
        </Card>

        {/* On Hold Tasks Card */}
        <Card className="p-6 hover:shadow-md transition-shadow" data-testid="card-hold-tasks">
          <div className="flex items-center">
            <div className="p-2 bg-red-100 rounded-lg">
              <PauseCircle className="text-red-600 h-5 w-5" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">On Hold</p>
              <p className="text-2xl font-bold text-red-600" data-testid="text-hold-count">
                {stats.hold}
              </p>
              <p className="text-xs text-gray-500" data-testid="text-hold-percentage">
                {stats.holdPercentage}%
              </p>
            </div>
          </div>
        </Card>
      </div>
    </section>
  );
}