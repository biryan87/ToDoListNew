import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Plus, Trash2, Download } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { insertTaskSchema, type InsertTask } from "@shared/schema";

export default function TaskForm() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<InsertTask>({
    resolver: zodResolver(insertTaskSchema),
    defaultValues: {
      title: "",
      priority: "medium",
      status: "pending",
    },
  });

  const createTaskMutation = useMutation({
    mutationFn: async (data: InsertTask) => {
      const response = await apiRequest("POST", "/api/tasks", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tasks/statistics"] });
      form.reset();
      toast({
        title: "Success",
        description: "New task created successfully!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create task. Please try again.",
        variant: "destructive",
      });
    },
  });

  const clearCompletedMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("DELETE", "/api/tasks/completed/clear");
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tasks/statistics"] });
      toast({
        title: "Success",
        description: `${data.count} completed tasks cleared!`,
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to clear completed tasks.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertTask) => {
    createTaskMutation.mutate(data);
  };

  const handleClearCompleted = () => {
    if (confirm("Are you sure you want to clear all completed tasks?")) {
      clearCompletedMutation.mutate();
    }
  };

  const handleExportTasks = () => {
    toast({
      title: "Export",
      description: "Task report export feature coming soon!",
    });
  };

  return (
    <Card>
      <CardContent className="p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Add New Task</h3>
        
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div>
            <Label htmlFor="task-title" className="text-sm font-medium text-gray-700">
              Task Title
            </Label>
            <Input
              id="task-title"
              data-testid="input-task-title"
              placeholder="Enter task description..."
              {...form.register("title")}
              className="mt-2"
            />
            {form.formState.errors.title && (
              <p className="text-sm text-red-600 mt-1">
                {form.formState.errors.title.message}
              </p>
            )}
          </div>
          
          <div>
            <Label htmlFor="task-priority" className="text-sm font-medium text-gray-700">
              Priority
            </Label>
            <Select 
              value={form.watch("priority")} 
              onValueChange={(value) => form.setValue("priority", value as "low" | "medium" | "high")}
            >
              <SelectTrigger className="mt-2" data-testid="select-task-priority">
                <SelectValue placeholder="Select priority" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="low">Low Priority</SelectItem>
                <SelectItem value="medium">Medium Priority</SelectItem>
                <SelectItem value="high">High Priority</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Button 
            type="submit"
            className="w-full"
            disabled={createTaskMutation.isPending}
            data-testid="button-add-task"
          >
            <Plus className="h-4 w-4 mr-2" />
            {createTaskMutation.isPending ? "Adding..." : "Add Task"}
          </Button>
        </form>

        {/* Quick Actions */}
        <div className="mt-6 pt-6">
          <Separator className="mb-4" />
          <h4 className="text-sm font-medium text-gray-700 mb-3">Quick Actions</h4>
          <div className="space-y-2">
            <Button
              variant="ghost"
              size="sm"
              className="w-full justify-start text-gray-600 hover:bg-gray-50"
              onClick={handleClearCompleted}
              disabled={clearCompletedMutation.isPending}
              data-testid="button-clear-completed"
            >
              <Trash2 className="h-4 w-4 mr-2 text-red-500" />
              {clearCompletedMutation.isPending ? "Clearing..." : "Clear Completed Tasks"}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="w-full justify-start text-gray-600 hover:bg-gray-50"
              onClick={handleExportTasks}
              data-testid="button-export-tasks"
            >
              <Download className="h-4 w-4 mr-2 text-blue-500" />
              Export Task Report
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}