import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Clock, LoaderPinwheel, CheckCircle, PauseCircle, Edit, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import EditTaskDialog from "@/components/edit-task-dialog";
import type { Task, TaskStatus } from "@shared/schema";

interface TaskItemProps {
  task: Task;
}

const statusConfig = {
  pending: {
    icon: Clock,
    className: "status-pending",
    label: "Pending"
  },
  progress: {
    icon: LoaderPinwheel,
    className: "status-progress",
    label: "In Progress"
  },
  completed: {
    icon: CheckCircle,
    className: "status-completed",
    label: "Completed"
  },
  hold: {
    icon: PauseCircle,
    className: "status-hold",
    label: "On Hold"
  }
};

export default function TaskItem({ task }: TaskItemProps) {
  const [showEditDialog, setShowEditDialog] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const updateTaskMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: Partial<Task> }) => {
      const response = await apiRequest("PATCH", `/api/tasks/${id}`, updates);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tasks/statistics"] });
      toast({
        title: "Success",
        description: "Task updated successfully!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update task. Please try again.",
        variant: "destructive",
      });
    },
  });

  const deleteTaskMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await apiRequest("DELETE", `/api/tasks/${id}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tasks/statistics"] });
      toast({
        title: "Success",
        description: "Task deleted successfully!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete task. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleStatusChange = (newStatus: TaskStatus) => {
    updateTaskMutation.mutate({
      id: task.id,
      updates: { status: newStatus }
    });
  };

  const handleDelete = () => {
    if (confirm("Are you sure you want to delete this task?")) {
      deleteTaskMutation.mutate(task.id);
    }
  };

  const statusInfo = statusConfig[task.status as TaskStatus];
  const StatusIcon = statusInfo.icon;

  const formatDate = (date: Date) => {
    const now = new Date();
    const diffMs = now.getTime() - new Date(date).getTime();
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffDays = Math.floor(diffHours / 24);

    if (diffDays > 0) {
      return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;
    } else if (diffHours > 0) {
      return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
    } else {
      return 'Just now';
    }
  };

  return (
    <>
      <div 
        className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:shadow-sm transition-shadow"
        data-testid={`task-item-${task.id}`}
      >
        <div className="flex items-center space-x-4 flex-1">
          <div className="flex-shrink-0">
            <Badge className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${statusInfo.className}`}>
              <StatusIcon className="mr-1 h-3 w-3" />
              {statusInfo.label}
            </Badge>
          </div>
          <div className="flex-1 min-w-0">
            <p 
              className={`text-sm font-medium truncate ${
                task.status === 'completed' ? 'text-gray-500 line-through' : 'text-gray-900'
              }`}
              data-testid={`text-task-title-${task.id}`}
            >
              {task.title}
            </p>
            <p className="text-xs text-gray-500 mt-1">
              <span className={`capitalize priority-${task.priority}`}>
                {task.priority} Priority
              </span>
              {" • "}
              <span data-testid={`text-task-date-${task.id}`}>
                {task.status === 'completed' 
                  ? `Completed ${formatDate(task.updatedAt)}`
                  : `Created ${formatDate(task.createdAt)}`
                }
              </span>
            </p>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          {/* Status Change Dropdown */}
          <Select 
            value={task.status} 
            onValueChange={handleStatusChange}
            disabled={updateTaskMutation.isPending}
          >
            <SelectTrigger 
              className="w-auto text-xs border border-gray-300 h-8"
              data-testid={`select-status-${task.id}`}
            >
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="progress">In Progress</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
              <SelectItem value="hold">On Hold</SelectItem>
            </SelectContent>
          </Select>

          <Button
            variant="ghost"
            size="sm"
            className="p-1.5 h-8 w-8 text-gray-400 hover:text-blue-600"
            onClick={() => setShowEditDialog(true)}
            data-testid={`button-edit-${task.id}`}
          >
            <Edit className="h-4 w-4" />
          </Button>
          
          <Button
            variant="ghost"
            size="sm"
            className="p-1.5 h-8 w-8 text-gray-400 hover:text-red-600"
            onClick={handleDelete}
            disabled={deleteTaskMutation.isPending}
            data-testid={`button-delete-${task.id}`}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <EditTaskDialog
        task={task}
        open={showEditDialog}
        onOpenChange={setShowEditDialog}
      />
    </>
  );
}